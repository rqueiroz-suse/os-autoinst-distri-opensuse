const loginScreenElements = require('../elements/loginScreen.json');
const chatScreenElements = require('../elements/chatScreen.json');
const signUpScreenElements = require('../elements/signUpScreen.json');
const workspaceScreenElements = require('../elements/workspaceScreen.json');
// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
Cypress.Commands.add('loginThroughApi', (email, password) => {
    return cy.request({
			method: 'POST',
			url: '/api/v1/auths/signin',
			body: {
				email: email,
				password: password
			},
			failOnStatusCode: false
		})
        .then((response) => {
			expect(response.status).to.be.oneOf([200, 400]);
            window.localStorage.setItem('token', response.body.token)
		})
})

Cypress.Commands.add('login', (email, password) => {
	cy.get(loginScreenElements.emailField).type(email);
	cy.get(loginScreenElements.passwordField).type(password);
	cy.get(loginScreenElements.submitButton).click();
})

Cypress.Commands.add('signUp', (userName, email, password) => {
    cy.get('button').contains('Sign up').click();
	cy.get(signUpScreenElements.userNameField).type(userName);
	cy.get(signUpScreenElements.emailField).type(email);
	cy.get(signUpScreenElements.passwordField).type(password);
	cy.get(signUpScreenElements.submitButton).click();
})

Cypress.Commands.add('closeChangelogDialogIfVisible', () => {
    cy.getAllLocalStorage().then((ls) => {
        if (!ls['version']) {
            cy.get('button').contains("Okay, Let's Go!").click();
        }
    });
})

Cypress.Commands.add('selectModelByName', (modelName) => {
    cy.get(chatScreenElements.homePageSection.selectModelDropdown).click();
    cy.get(chatScreenElements.homePageSection.modelSearchInputField).should('be.visible').type(modelName);
	cy.get(chatScreenElements.homePageSection.modelListItem).first().click();
    cy.get(chatScreenElements.homePageSection.modelSelectedText).contains(modelName);
})

Cypress.Commands.add('inputQuestionAndSubmit', (question) => {
    cy.get(chatScreenElements.homePageSection.questionInputField).type(question , { force: true });
    cy.get(chatScreenElements.homePageSection.submitQuestionButton).click();
})

Cypress.Commands.add('checkIfUserChatExists', () => {
    cy.get(chatScreenElements.chatScreenSection.chatUserText).should('exist');
})

Cypress.Commands.add('checkIfAssistantChatExists', () => {
    cy.get(chatScreenElements.chatScreenSection.chatAssistantText).should('exist');
})

Cypress.Commands.add('checkIfGenerateInfoIconExists', () => {
    // Generation Info is created after the stop token is received
    cy.get(chatScreenElements.chatScreenSection.generateInfoIcon).should('exist');
})

Cypress.Commands.add('generateImage', () => {
    cy.get(chatScreenElements.chatScreenSection.generateImageIcon).click();
	cy.get(chatScreenElements.chatScreenSection.imageGeneratedElement).should('be.visible');
})

Cypress.Commands.add('createEmptyKnowledge', (knowledgeName) => {
    cy.get("#sidebar-toggle-button").click();
    cy.get('div')
        .contains('Workspace')
        .should('be.visible')
        .click();
    cy.get('div a')
        .contains('Knowledge')
        .should('be.visible')
        .click();

    cy.get(workspaceScreenElements.knowledgeScreen.createKnowledgeButton).click();
    cy.get(workspaceScreenElements.knowledgeScreen.knowledgeNameField)
        .should('be.visible')
        .type(knowledgeName);
    cy.get(workspaceScreenElements.knowledgeScreen.knowledgeDescriptionField)
        .type("Test Purposes");
    cy.get("[type='submit']").click();

    cy.get("[data-title]").contains("Knowledge created successfully");
})

Cypress.Commands.add('addContentToKnowledge', (fileToBeUploaded) => {
    cy.get(workspaceScreenElements.knowledgeScreen.addContentButton).click();
    cy.get(workspaceScreenElements.knowledgeScreen.inputFileField).selectFile(fileToBeUploaded, {force: true});

    cy.get("[data-title]").contains("File added successfully");
})

Cypress.Commands.add('createCustomModel', (modelName) => {
    cy.get('div a').contains('Models').should('be.visible').click();
    cy.get('div').contains('Create a model').click();
        
    cy.get(workspaceScreenElements.modelsScreen.modelName)
        .should('be.enabled')
        .type(modelName);
    cy.get(workspaceScreenElements.modelsScreen.baseModelDropdown)
        .select(Cypress.env("BASE_MODEL"));
    cy.get('button').contains("Select Knowledge").click();
    cy.get(workspaceScreenElements.modelsScreen.searchKnowledgeField)
        .should('be.visible')
        .type("OWUI-Docs");
    cy.get('[data-menu-item]').first().click();
    cy.get('button div').contains('Save & Create').click();

    cy.get("[data-title]").contains("Model created successfully");
})