describe('Workspace Functionality - Test Suite', () => {

    let knowledgeName = `owui-docker-${Date.now()}`;
    let knowledgeFilePath = "./cypress/fixtures/OWUI-Docker.pdf";
    

    beforeEach(() => {
        cy.log(Cypress.env('OPENWEBUI_ADMIN_EMAIL'));
        cy.loginThroughApi(
            Cypress.env('OPENWEBUI_ADMIN_EMAIL'), 
            Cypress.env('OPENWEBUI_ADMIN_PWD')
        );
        cy.visit("/");
        cy.closeChangelogDialogIfVisible();
    })

    it('1 - Upload Knowledge File', () => {
        cy.createEmptyKnowledge(knowledgeName);
        cy.addContentToKnowledge(knowledgeFilePath);
    })

    it('2 - Create Custom model', () => {
        let modelName = `owuidocs-${Date.now()}`;

        cy.createEmptyKnowledge(knowledgeName);
        cy.addContentToKnowledge(knowledgeFilePath);

        cy.createCustomModel(modelName);
    })

    it('3 - Using custom model to query', () => {
        let modelName = `owuidocs-${Date.now()}`;

        cy.createEmptyKnowledge(knowledgeName);
        cy.addContentToKnowledge(knowledgeFilePath);

        cy.createCustomModel(modelName);

        cy.get('div')
            .contains('New Chat')
            .should('be.visible')
            .click();
        
        cy.selectModelByName(modelName);
        cy.inputQuestionAndSubmit("Which steps I have to follow to install OpenWebUI with GPU Support using Docker?");
        cy.checkIfUserChatExists();
        cy.checkIfAssistantChatExists();
        cy.checkIfGenerateInfoIconExists();
    })
})