const chatScreenElements = require('../elements/chatScreen.json');

describe('Registration and Login - Test Suite', () => {
    beforeEach(() => {
        cy.visit('/');
    })

    it('1 - Register new user as Pending', () => {
        const userName = `Test User - ${Date.now()}`;
		const userEmail = `cypress-${Date.now()}@example.com`;
        const password = `test-${Date.now()}`

		cy.signUp(userName, userEmail, password)
		cy.contains(userName);
		cy.contains('Check Again');
    })

    it('2 - Login as Admin', () => {
        cy.login(
            Cypress.env('OPENWEBUI_ADMIN_EMAIL'), 
            Cypress.env('OPENWEBUI_ADMIN_PWD')
        )
		cy.closeChangelogDialogIfVisible();
		cy.get(chatScreenElements.homePageSection.questionInputField).should('be.visible');
    })
})