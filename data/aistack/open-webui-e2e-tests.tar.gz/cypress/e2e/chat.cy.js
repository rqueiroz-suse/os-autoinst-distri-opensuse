const chatScreenElements = require('../elements/chatScreen.json');

describe("Chat Functionality - Test Suite", () => {
    beforeEach(() => {
        cy.log(Cypress.env('OPENWEBUI_ADMIN_EMAIL'));
        cy.loginThroughApi(
            Cypress.env('OPENWEBUI_ADMIN_EMAIL'), 
            Cypress.env('OPENWEBUI_ADMIN_PWD')
        );
        cy.visit("/");
        cy.closeChangelogDialogIfVisible();
    })

    it('1 - Select a model', () => {
        cy.selectModelByName(Cypress.env("BASE_MODEL"));
    })

    it('2 - Ask a question and receive answer', () => {
        cy.selectModelByName(Cypress.env("BASE_MODEL"));
        cy.inputQuestionAndSubmit("Hi, what can you do? A single sentence only please.");
        cy.checkIfUserChatExists();
        cy.checkIfAssistantChatExists();
        cy.checkIfGenerateInfoIconExists();
    });

    xit('3 - Generate image', () => {
        cy.selectModelByName(Cypress.env("BASE_MODEL"));
        cy.inputQuestionAndSubmit("Hi, what can you do? A single sentence only please.");
        cy.checkIfUserChatExists();
        cy.checkIfAssistantChatExists();
        cy.checkIfGenerateInfoIconExists();
        cy.generateImage();
    });
})