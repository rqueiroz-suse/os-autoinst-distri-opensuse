const { defineConfig } = require("cypress");

module.exports = defineConfig({
  e2e: {
    baseUrl: "https://suse-ollama-webui",
    defaultCommandTimeout: 25000
  },
});
