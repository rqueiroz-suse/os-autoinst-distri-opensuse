import csv

import pytest
import os

from actions.main.files import upload_file
from testData.mainApi.testData import create_chat_with_model_payload, update_chat_payload, \
    update_chat_with_processed_data_payload, create_chat_completion_payload, update_chat_with_title_payload, \
    update_chat_with_file_payload
from testData.ollamaApi.testData import create_generate_chat_payload
from actions.main.mainApi import create_chat, update_chat, create_chat_completion
from actions.ollamaApi.ollamaApi import generateChat
from actions.auth import do_login


@pytest.fixture()
def setup_data():
    base_url = f"{os.getenv("LOCAL_URL")}:{os.getenv("PORT")}"
    login_response = do_login(os.getenv('OPENWEBUI_ADMIN'), os.getenv('OPENWEBUI_PASSWD'), base_url)

    yield login_response.json()['token'], base_url


def test_generate_update_delete_chat(setup_data):
    auth_token, base_url = setup_data
    content_to_be_processed = "Help me! There's a dragon throwing flames on me!"

    create_new_chat_response = create_chat(auth_token, create_chat_with_model_payload(), base_url).json()
    chat_id = create_new_chat_response['id']
    assert chat_id is not None, "[ERROR] The chat was not created"

    update_chat_response = update_chat(auth_token, chat_id, update_chat_payload(content_to_be_processed), base_url).json()
    last_message_sent_id = update_chat_response["chat"]["history"]["currentId"]

    generate_chat_response = generateChat(auth_token, create_generate_chat_payload(content_to_be_processed), base_url)
    content_processed = generate_chat_response.json()["message"]["content"]
    update_with_chat_processed = update_chat(
        auth_token,
        chat_id,
        update_chat_with_processed_data_payload(
            last_message_sent_id,
            content_to_be_processed,
            content_processed
        ), base_url).json()

    generate_title_response = create_chat_completion(auth_token, create_chat_completion_payload(chat_id, update_with_chat_processed["chat"]["messages"]), base_url).json()
    update_title = update_with_chat_processed | { "title": generate_title_response["choices"][0]["message"]["content"] }
    update_title["chat"]["title"] = generate_title_response["choices"][0]["message"]["content"]

    final_update_chat_response = update_chat(
        auth_token,
        chat_id,
        update_title,
        base_url
        )
    assert final_update_chat_response.status_code == 200


def test_file_upload(setup_data):
    auth_token, base_url = setup_data
    file_path = "../../resources/nytimes_best_restaurants_2024.csv"

    file_upload_response = upload_file(auth_token, file_path, base_url).json()

    auth_token, base_url = setup_data
    content_to_be_processed = "In which city is located the restaurant L'Orange?"

    create_new_chat_response = create_chat(auth_token, create_chat_with_model_payload(), base_url).json()
    chat_id = create_new_chat_response['id']
    user_id = create_new_chat_response['user_id']
    assert chat_id is not None, "[ERROR] The chat was not created"

    update_chat_response = update_chat(auth_token,
                                       chat_id,
                                       update_chat_with_file_payload(
                                           chat_id,
                                           user_id,
                                           content_to_be_processed,
                                           file_upload_response
                                       ),
                                       base_url).json()
    print(update_chat_response)
    # last_message_sent_id = update_chat_response["chat"]["history"]["currentId"]
    # print(last_message_sent_id)
    # generate_chat_response = generateChat(auth_token, create_generate_chat_payload(content_to_be_processed), base_url)
    # content_processed = generate_chat_response.json()["message"]["content"]
    # update_with_chat_processed = update_chat(
    #     auth_token,
    #     chat_id,
    #     update_chat_with_processed_data_payload(
    #         last_message_sent_id,
    #         content_to_be_processed,
    #         content_processed
    #     ), base_url).json()
    #
    # generate_title_response = create_chat_completion(auth_token, create_chat_completion_payload(chat_id,
    #                                                                                             update_with_chat_processed[
    #                                                                                                 "chat"][
    #                                                                                                 "messages"]),
    #                                                  base_url).json()
    # update_title = update_with_chat_processed | {"title": generate_title_response["choices"][0]["message"]["content"]}
    # update_title["chat"]["title"] = generate_title_response["choices"][0]["message"]["content"]
    #
    # final_update_chat_response = update_chat(
    #     auth_token,
    #     chat_id,
    #     update_title,
    #     base_url
    # )
    # assert final_update_chat_response.status_code == 200

