import os
import pytest
import requests

from actions.auth import do_login

@pytest.fixture()
def setup_data(get_base_url):
    base_url = get_base_url
    login_response = do_login(os.getenv('OPENWEBUI_ADMIN'), os.getenv('OPENWEBUI_PASSWD'), base_url)
    yield login_response.json()['token'], base_url


def upload_file(auth_token, file_path, base_url):
    try:
        file = {"file": (file_path, open(file_path, "rb"), "text/csv")}
        response = requests.post(f'{base_url}/api/v1/files', files=file,
                                    headers={
                                         "authorization": f'Bearer {auth_token}'
                                    },
                                    verify=False)
        return response
    except FileNotFoundError:
        print("The file was not found.")
    except requests.exceptions.RequestException as e:
        print("There was an exception that occurred while handling your request.", e)



