import requests
from dotenv import load_dotenv

load_dotenv()

def generateChat(auth_token, payload, base_url):
    response = requests.post(f'{base_url}/ollama/api/chat', json=payload,
                             headers={
                                 "Content-Type": "application/json",
                                 "authorization": f"Bearer {auth_token}"
                             },
                             verify=False)

    return response