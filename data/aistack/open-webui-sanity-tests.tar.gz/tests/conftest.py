import os

import pytest
from dotenv import load_dotenv

load_dotenv()

def pytest_addoption(parser):

    parser.addoption("--OPENWEBUI-ADMIN-EMAIL", action="store", default="local", help="Input email credential")
    parser.addoption("--OPENWEBUI-ADMIN-PWD", action="store", default="local", help="Input password credential")
    parser.addoption("--URL", action="store", default="local", help="Input Base URL")

@pytest.fixture(autouse=True)
def get_config(request):

    env = request.config.getoption('--URL')
    creds_email = request.config.getoption('--OPENWEBUI-ADMIN-EMAIL')
    creds_pwd = request.config.getoption('--OPENWEBUI-ADMIN-PWD')

    yield env, creds_email, creds_pwd

