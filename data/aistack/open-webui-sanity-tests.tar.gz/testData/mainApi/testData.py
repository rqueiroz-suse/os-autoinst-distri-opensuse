import os
import uuid

from dotenv import load_dotenv

load_dotenv()


def create_empty_chat_payload():
    payload = {
        "chat": {}
    }
    return payload


def create_chat_with_model_payload():
  payload = {
    "chat": {
      "models": [
        os.getenv("MODEL")
      ],
      "messages": []
    }
  }

  return payload


def update_chat_payload(content):
    role_user_uuid = str(uuid.uuid4())
    payload = {
      "chat": {
        "models": [
          os.getenv("MODEL")
        ],
        "history": {
          "currentId": role_user_uuid,
          "messages": {
            role_user_uuid: {
              "id": role_user_uuid,
              "parentId": None,
              "role": "user",
              "content": content,
              "timestamp": 1727105180,
              "models": [
                os.getenv("MODEL")
              ]
            }
          },
        },
        "messages": [
          {
            "id": role_user_uuid,
            "parentId": None,
            "role": "user",
            "content": content,
            "timestamp": 1727105180,
            "models": [
              os.getenv("MODEL")
            ]
          }
        ]
      }
    }
    return payload


def update_chat_with_processed_data_payload(role_user_uuid, content, content_processed):
  model = os.getenv("MODEL")
  role_assistant_uuid = str(uuid.uuid4())
  payload = {
    "chat": {
      "title": "",
      "models": [
        model
      ],
      "history": {
        "currentId": role_assistant_uuid,
        "messages": {
          role_assistant_uuid: {
            "role": "assistant",
            "content": content_processed,
            "model": model,
            "id": role_assistant_uuid,
            "parentId": role_user_uuid,
            "childrenIds": [],
            "done": True,
            "modelName": model,
          },
          role_user_uuid: {
            "id": role_user_uuid,
            "parentId": None,
            "childrenIds": [
              role_assistant_uuid
            ],
            "role": "user",
            "content": content,
            "models": [
              model
            ]
          }
        },
      },
      "messages": [
        {
          "role": "assistant",
          "content": content_processed,
          "models": model,
          "id": role_assistant_uuid,
          "parentId": role_user_uuid,
          "childrenIds": [],
          "done": True,
          "modelName": model,
        },
        {
          "id": role_user_uuid,
          "parentId": None,
          "childrenIds": [
            role_assistant_uuid
          ],
          "role": "user",
          "content": content,
          "models": [
            model
          ]
        }
      ]
    }
  }
  return payload


def create_chat_completion_payload(chat_id, messages):
  payload = {
    "chat_id": chat_id,
    "messages": messages,
    "model": os.getenv("MODEL")
  }
  return payload


def update_chat_with_title_payload(chat_title):
  payload = {
    "title": chat_title
  }
  return payload


def update_chat_with_file_payload(chat_id, user_id, content, file_payload):
  role_user_uuid = str(uuid.uuid4())
  file_id = file_payload["id"]
  file_name = file_payload["meta"]["name"]
  file_size = file_payload["meta"]["size"]
  item_id = str(uuid.uuid4())
  payload = {
      "id": chat_id,
      "user_id": user_id,
      "title": "New Chat",
      "chat": {
        "models": [
          os.getenv("MODEL")
        ],
        "history": {
          "currentId": role_user_uuid,
          "messages": {
            role_user_uuid: {
              "id": role_user_uuid,
              "parentId": None,
              "role": "user",
              "content": content,
              "timestamp": 1727105180,
              "models": [
                os.getenv("MODEL")
              ],
              "files": {
                "type": "file",
                "file": [file_payload],
                "id": file_id,
                "url": f"/api/v1/files/{file_id}",
                "name": file_name,
                "collection_name": f"file-{file_id}",
                "status": "uploaded",
                "size": file_size,
                "error": "",
                "itemId": item_id
              }
            }
          },
        },
        "messages": [
          {
            "id": role_user_uuid,
            "parentId": None,
            "role": "user",
            "content": content,
            "timestamp": 1727105180,
            "models": [
              os.getenv("MODEL")
            ],
            "files": {
              "type": "file",
              "file": file_payload,
              "id": file_id,
              "url": f"/api/v1/files/{file_id}",
              "name": file_name,
              "collection_name": f"file-{file_id}",
              "status": "uploaded",
              "size": file_size,
              "error": "",
              "itemId": item_id
            }
          }
        ]
      }
    }
  return payload